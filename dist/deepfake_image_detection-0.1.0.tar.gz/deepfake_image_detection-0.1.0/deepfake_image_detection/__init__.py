from .main import classify_image_from_url
